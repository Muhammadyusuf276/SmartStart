import React, { useState, useRef } from 'react';
import { Shield, Sparkles, Menu, X, GraduationCap, Sun, Moon } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Language } from '../i18n/translations';

interface NavbarProps {
  currentScreen: 'home' | 'results' | 'featured' | 'admin';
  onNavigate: (screen: 'home' | 'results' | 'featured' | 'admin') => void;
  onOpenAdmission: () => void;
  featuredCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onNavigate,
  onOpenAdmission,
  featuredCount
}) => {
  const { language, setLanguage, theme, toggleTheme, t } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const clickTimestampsRef = useRef<number[]>([]);
  const [secretClickHint, setSecretClickHint] = useState<number>(0);

  const languages: { code: Language; label: string }[] = [
    { code: 'uz', label: 'UZ' },
    { code: 'ru', label: 'RU' },
    { code: 'en', label: 'EN' }
  ];

  // Secret Admin Access via Triple-Click on Smart Start Logo
  const handleLogoClick = () => {
    const now = Date.now();
    const recent = [...clickTimestampsRef.current.filter((time) => now - time < 1200), now];
    clickTimestampsRef.current = recent;
    setSecretClickHint(recent.length);

    setTimeout(() => {
      setSecretClickHint(0);
    }, 1400);

    if (recent.length >= 3) {
      clickTimestampsRef.current = [];
      setSecretClickHint(0);
      onNavigate('admin');
    } else {
      onNavigate('home');
    }
  };

  const handleNavClick = (sectionId: string) => {
    if (currentScreen !== 'home') {
      onNavigate('home');
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top Prototype Switcher & Quick Utility Bar */}
      <div className="bg-[#0B1A33] dark:bg-slate-950 text-white border-b border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
            <span className="font-bold tracking-wider text-slate-300 uppercase text-[11px] truncate">
              {t.topNotice}
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Screen switcher */}
            <div className="flex items-center gap-1 bg-slate-900/90 dark:bg-slate-900 p-0.5 rounded-lg border border-slate-700">
              <button
                type="button"
                onClick={() => onNavigate('home')}
                className={`px-3 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                  currentScreen === 'home'
                    ? 'bg-[#CF9E2E] text-[#0B1A33] shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Bosh sahifa
              </button>
              <button
                type="button"
                onClick={() => onNavigate('results')}
                className={`px-3 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                  currentScreen === 'results'
                    ? 'bg-[#CF9E2E] text-[#0B1A33] shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Natijalar qidiruvi
              </button>
              {currentScreen === 'admin' && (
                <button
                  type="button"
                  onClick={() => onNavigate('admin')}
                  className="px-3 py-1 rounded-md font-bold text-xs bg-[#CF9E2E] text-[#0B1A33] shadow-sm flex items-center gap-1 cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span>{t.protoAdmin}</span>
                </button>
              )}
            </div>

            {/* Language Switcher Buttons (UZ | RU | EN without flag emojis) */}
            <div className="flex items-center bg-slate-900/90 dark:bg-slate-900 p-0.5 rounded-lg border border-slate-700 text-xs">
              {languages.map((l) => (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => setLanguage(l.code)}
                  className={`px-2.5 py-1 rounded-md font-extrabold uppercase transition-all cursor-pointer ${
                    language === l.code
                      ? 'bg-amber-400 text-slate-950 shadow-2xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>

            {/* Theme Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              title={theme === 'dark' ? t.themeLight : t.themeDark}
              className="p-1.5 rounded-lg bg-slate-900/90 dark:bg-slate-900 hover:bg-slate-800 border border-slate-700 text-amber-300 hover:text-amber-200 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span className="hidden sm:inline text-[11px] text-slate-300">Kun</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-amber-300" />
                  <span className="hidden sm:inline text-[11px] text-slate-300">Tun</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main School Header */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
          {/* Logo & School Name - Secret 3-Click triggers Admin Access! */}
          <button
            type="button"
            onClick={handleLogoClick}
            title="Smart Start"
            className="flex items-center gap-3 text-left focus:outline-none group cursor-pointer relative"
          >
            <div className="relative">
              <img
                src="/smart-start-logo.png"
                alt="Smart Start Logo"
                className={`w-12 h-12 object-contain rounded-xl group-hover:scale-105 transition-transform ${
                  secretClickHint >= 2 ? 'ring-2 ring-amber-400 ring-offset-2' : ''
                }`}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/assets/b9beb49f5a7d0c49502c2b2852bb209a.png';
                }}
              />
              {secretClickHint > 0 && secretClickHint < 3 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-extrabold flex items-center justify-center animate-bounce shadow-md">
                  {secretClickHint}/3
                </span>
              )}
            </div>

            <div className="flex flex-col leading-tight">
              <span className="font-display font-bold text-xl text-[#13294B] dark:text-white tracking-tight group-hover:text-[#CF9E2E] transition-colors">
                {t.schoolName}
              </span>
              <span className="text-[10px] font-extrabold tracking-[2px] text-slate-500 dark:text-slate-400 uppercase">
                {t.schoolSubtitle}
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links (Directly matching wireframe) */}
          <nav className="hidden lg:flex items-center gap-5 xl:gap-6 text-xs xl:text-sm font-semibold text-slate-700 dark:text-slate-300">
            <button
              onClick={() => handleNavClick('haqida')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              Maktab haqida
            </button>
            <button
              onClick={() => handleNavClick('natijalar')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              Natijalar
            </button>
            <button
              onClick={() => handleNavClick('talim')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              Ta'lim
            </button>
            <button
              onClick={() => handleNavClick('hamkorlar')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              Hamkorlar
            </button>
            <button
              onClick={() => handleNavClick('oqituvchilar')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              O'qituvchilar
            </button>
            <button
              onClick={() => handleNavClick('qabul')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              Qabul
            </button>
            <button
              onClick={() => handleNavClick('yangiliklar')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              Yangiliklar
            </button>
            <button
              onClick={() => handleNavClick('aloqa')}
              className="hover:text-[#13294B] dark:hover:text-amber-400 transition-colors py-1 cursor-pointer"
            >
              Aloqa
            </button>
          </nav>

          {/* Right Action Button (Only Qabulga yozilish, public Admin button is hidden) */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              type="button"
              onClick={onOpenAdmission}
              className="px-5 py-2.5 rounded-xl bg-[#CF9E2E] hover:bg-[#b88c27] active:scale-95 text-[#13294B] font-extrabold text-sm transition-all shadow-sm shadow-amber-200 dark:shadow-none flex items-center gap-1.5 cursor-pointer"
            >
              <GraduationCap className="w-4 h-4" />
              <span>Qabulga yozilish</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            aria-label="Menyu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-2.5 shadow-lg">
            {[
              { id: 'haqida', label: 'Maktab haqida' },
              { id: 'natijalar', label: 'Natijalar' },
              { id: 'talim', label: "Ta'lim" },
              { id: 'hamkorlar', label: 'Hamkorlar' },
              { id: 'oqituvchilar', label: "O'qituvchilar" },
              { id: 'qabul', label: 'Qabul' },
              { id: 'yangiliklar', label: 'Yangiliklar' },
              { id: 'aloqa', label: 'Aloqa' }
            ].map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className="w-full text-left font-bold text-sm text-slate-800 dark:text-slate-100 py-1.5 border-b border-slate-100 dark:border-slate-800 cursor-pointer"
              >
                {link.label}
              </button>
            ))}

            {/* Mobile Lang & Theme Toggles */}
            <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                {t.langSelect}:
              </span>
              <div className="flex items-center gap-1">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => setLanguage(l.code)}
                    className={`px-2.5 py-1 rounded text-xs font-extrabold uppercase cursor-pointer ${
                      language === l.code
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                onOpenAdmission();
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 text-center rounded-xl bg-[#CF9E2E] text-[#13294B] font-extrabold text-sm shadow-sm cursor-pointer"
            >
              {t.applyBtn}
            </button>
          </div>
        )}
      </header>
    </>
  );
};
