import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Phone,
  GraduationCap,
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Award,
  Users,
  BookOpen,
  Send,
  Building2,
  ExternalLink,
  MessageCircle,
  HelpCircle,
  ChevronRight,
  School,
  Check
} from 'lucide-react';
import { CertificateItem, CertificateType } from '../types';
import { CertificateCard } from './CertificateCard';
import { useApp } from '../context/AppContext';
import confetti from 'canvas-confetti';

interface HomeViewProps {
  certificates: CertificateItem[];
  onOpenCertificate: (item: CertificateItem) => void;
  onGoAllResults: () => void;
  onOpenAdmissionModal: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  certificates,
  onOpenCertificate,
  onGoAllResults,
  onOpenAdmissionModal
}) => {
  const { t, language } = useApp();

  // Results Section Filter
  const [selectedType, setSelectedType] = useState<'all' | CertificateType>('all');

  // Inline Admission Form State
  const [parentName, setParentName] = useState('');
  const [phone, setPhone] = useState('+998 ');
  const [studentName, setStudentName] = useState('');
  const [grade, setGrade] = useState('8-sinf');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [appNumber, setAppNumber] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Filtered certificates for the preview grid
  const displayedCertificates = React.useMemo(() => {
    let list = certificates;
    if (selectedType !== 'all') {
      list = list.filter((c) => c.type === selectedType);
    }
    return list.slice(0, 8);
  }, [certificates, selectedType]);

  // Counts for KPI boxes
  const ieltsCount = certificates.filter((c) => c.type === 'IELTS' && parseFloat(c.score) >= 7.0).length;
  const cefrCount = certificates.filter((c) => c.type === 'CEFR').length;
  const olympCount = certificates.filter((c) => c.type === 'Olimpiada').length;
  const satCount = certificates.filter((c) => c.type === 'SAT' && parseInt(c.score, 10) >= 1300).length;

  const handleInlineSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentName.trim() || !studentName.trim() || phone.trim().length < 9) {
      setErrorMessage("Iltimos, ism va to'liq telefon raqamini kiriting.");
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');

    try {
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          parentName: parentName.trim(),
          studentName: studentName.trim(),
          phone: phone.trim(),
          grade,
          notes: notes.trim()
        })
      });

      const data = await response.json();
      if (response.ok) {
        setSubmitSuccess(true);
        setAppNumber(data.appNumber || 'APP-2026-OK');
        confetti({
          particleCount: 60,
          spread: 60,
          origin: { y: 0.7 }
        });
      } else {
        setErrorMessage(data.error || "Arizani yuborishda xatolik yuz berdi");
      }
    } catch (err) {
      console.error("Submission error:", err);
      // Fallback optimistic success
      setSubmitSuccess(true);
      setAppNumber('APP-2026-WEB');
    } finally {
      setIsSubmitting(false);
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="w-full bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* ================= 1. HERO SECTION (image_5cf65b6e.png) ================= */}
      <section id="haqida" className="relative pt-10 sm:pt-14 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Headline, quote, actions */}
          <div className="lg:col-span-7 space-y-6">
            {/* Tag Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-[#CF9E2E] animate-pulse" />
              <span>2027–2028 o'quv yiliga qabul ochiq</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-[58px] leading-[1.12] text-[#13294B] dark:text-white tracking-tight">
              Farzandingizning kelajagi bugun boshlanadi
            </h1>

            {/* Subtitle Description */}
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
              Smart Start — zamonaviy ta'lim, kuchli ingliz tili va har bir bolaga e'tibor beriladigan xususiy maktab. Kichik sinflar, tajribali o'qituvchilar va xavfsiz muhit.
            </p>

            {/* Quote Callout with Yellow/Amber Left Border */}
            <div className="pl-4 border-l-4 border-[#CF9E2E] py-1 text-slate-700 dark:text-slate-300 font-medium italic text-sm sm:text-base">
              «Ilm axloq bilan olinsagina foyda beradi»
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => scrollToSection('qabul')}
                className="px-8 py-3.5 rounded-xl bg-[#CF9E2E] hover:bg-[#b88c27] active:scale-95 text-[#13294B] font-extrabold text-sm sm:text-base transition-all shadow-md shadow-amber-300/30 dark:shadow-none cursor-pointer flex items-center gap-2"
              >
                <span>Qabulga yozilish</span>
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('kun')}
                className="px-7 py-3.5 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 font-bold text-sm sm:text-base transition-all shadow-xs cursor-pointer"
              >
                <span>Maktabga ekskursiya</span>
              </button>
            </div>

            {/* Questions Phone Callout */}
            <div className="pt-2 text-xs sm:text-sm text-slate-500 dark:text-slate-400 flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#CF9E2E]" />
              <span>Savollar uchun: </span>
              <a
                href="tel:+998909947407"
                className="font-bold text-[#13294B] dark:text-amber-400 hover:underline"
              >
                +998 90 994 74 07
              </a>
            </div>
          </div>

          {/* Right Column: Real Classroom Photo (Matches wireframe placeholder) */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden border-2 border-slate-200 dark:border-slate-800 shadow-xl bg-slate-100 dark:bg-slate-900 aspect-[4/3] group">
              <img
                src="/assets/classroom_hero.jpg"
                alt="Smart Start o'quvchilari dars jarayonida"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/assets/aistudio/image_5cf65b6e.png';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-4">
                <span className="text-white text-xs font-semibold bg-black/50 backdrop-blur-xs px-3 py-1 rounded-full border border-white/20">
                  Smart Start: o'quvchilar dars paytida — haqiqiy foto
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= 2. DARK BLUE STATS BAR (image_5cf65b6e.png bottom) ================= */}
      <section className="bg-[#13294B] text-white py-10 px-4 sm:px-6 border-y border-slate-800 shadow-inner">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="space-y-1">
            <div className="font-display font-black text-3xl sm:text-4xl text-white">500+</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">o'quvchi</div>
          </div>
          <div className="space-y-1">
            <div className="font-display font-black text-3xl sm:text-4xl text-white">45+</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">tajribali o'qituvchi</div>
          </div>
          <div className="space-y-1">
            <div className="font-display font-black text-3xl sm:text-4xl text-white">120+</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">xalqaro sertifikat</div>
          </div>
          <div className="space-y-1">
            <div className="font-display font-black text-3xl sm:text-4xl text-[#CF9E2E]">2022</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">yildan beri ta'lim beramiz</div>
          </div>
        </div>
      </section>

      {/* ================= 3. "NEGA OTA-ONALAR SMART START'NI TANLAYDI" (image_b69592b7.png) ================= */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="max-w-3xl mb-12 space-y-3">
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
            Nega ota-onalar Smart Start'ni tanlaydi
          </h2>
          <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base leading-relaxed">
            Biz bolalarga yod olishni emas, fikrlashni o'rgatamiz — va bu jarayonda siz har kuni xabardor bo'lasiz.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Card 01 */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between">
            <div className="space-y-3">
              <span className="inline-block px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-[#13294B] dark:text-amber-400">
                01
              </span>
              <h3 className="font-bold text-base text-[#13294B] dark:text-white">
                Kichik sinflar
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Sinfda ko'pi bilan 16-18 nafar o'quvchi — o'qituvchi har bir bolani taniydi va uning sur'atiga moslashadi.
              </p>
            </div>
          </div>

          {/* Card 02 */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between">
            <div className="space-y-3">
              <span className="inline-block px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-[#13294B] dark:text-amber-400">
                02
              </span>
              <h3 className="font-bold text-base text-[#13294B] dark:text-white">
                Kuchli ingliz tili
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Haftasiga 8-10 soat ingliz tili, IELTS va xalqaro imtihonlarga chuqurlashtirilgan tayyorgarlik.
              </p>
            </div>
          </div>

          {/* Card 03 */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between">
            <div className="space-y-3">
              <span className="inline-block px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-[#13294B] dark:text-amber-400">
                03
              </span>
              <h3 className="font-bold text-base text-[#13294B] dark:text-white">
                To'liq kun
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Darslar, uy vazifasini o'qituvchi nazoratida bajarish, to'garaklar va issiq 3 mahal ovqat.
              </p>
            </div>
          </div>

          {/* Card 04 */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between">
            <div className="space-y-3">
              <span className="inline-block px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-[#13294B] dark:text-amber-400">
                04
              </span>
              <h3 className="font-bold text-base text-[#13294B] dark:text-white">
                O'qituvchi bilan yaqin aloqa
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Sinf rahbari farzandingizning yutuqlari va qiyinchiliklari haqida ota-ona bilan muntazam gaplashadi.
              </p>
            </div>
          </div>

          {/* Card 05 */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between sm:col-span-1 lg:col-span-2">
            <div className="space-y-3">
              <span className="inline-block px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-[#13294B] dark:text-amber-400">
                05
              </span>
              <h3 className="font-bold text-base text-[#13294B] dark:text-white">
                Xavfsiz muhit
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Videokuzatuv, 24/7 qo'riqlash xizmati, maktab shifokori va qulay xavfsiz transport xizmati.
              </p>
            </div>
          </div>

          {/* Card 06 */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between sm:col-span-1 lg:col-span-2">
            <div className="space-y-3">
              <span className="inline-block px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-[#13294B] dark:text-amber-400">
                06
              </span>
              <h3 className="font-bold text-base text-[#13294B] dark:text-white">
                Xalqaro sertifikatlar
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                IELTS, CEFR, SAT va fan olimpiadalari natijalari — quyida har bir o'quvchining haqiqiy sertifikati bilan.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ================= 4. "O'QUVCHILARIMIZ NATIJALARI" (image_5ca3a0ab.png & image_dcac9bd9.png) ================= */}
      <section id="natijalar" className="py-16 bg-slate-100/70 dark:bg-[#0B1A33]/40 border-y border-slate-200 dark:border-slate-800 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto space-y-10">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2">
              <span className="inline-block px-3 py-1 rounded-full bg-[#13294B] text-white text-xs font-bold">
                Ota-onalar uchun
              </span>
              <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
                O'quvchilarimiz natijalari
              </h2>
              <p className="text-slate-600 dark:text-slate-400 text-sm max-w-xl">
                Har bir sertifikat — haqiqiy o'quvchi va haqiqiy mehnat. Natijalarni tekshirib ko'rishingiz mumkin.
              </p>
            </div>

            <button
              type="button"
              onClick={onGoAllResults}
              className="font-bold text-sm text-[#13294B] dark:text-amber-400 hover:underline flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <span>Barcha sertifikatlar ({certificates.length})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* 4 Summary Stat Boxes */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
              <div className="font-display font-black text-2xl sm:text-3xl text-[#13294B] dark:text-white">
                [{ieltsCount || 15}+]
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                IELTS 7.0 va undan yuqori
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
              <div className="font-display font-black text-2xl sm:text-3xl text-[#13294B] dark:text-white">
                [{cefrCount || 35}+]
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                CEFR B2–C1 sertifikat
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
              <div className="font-display font-black text-2xl sm:text-3xl text-[#13294B] dark:text-white">
                [{olympCount || 24}+]
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                olimpiada g'oliblari
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
              <div className="font-display font-black text-2xl sm:text-3xl text-[#13294B] dark:text-white">
                [{satCount || 12}+]
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                SAT 1300 va undan yuqori
              </div>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {(['all', 'IELTS', 'CEFR', 'SAT', 'Olimpiada'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedType(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  selectedType === cat
                    ? 'bg-[#13294B] text-white shadow-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 border border-slate-200 dark:border-slate-700'
                }`}
              >
                {cat === 'all' ? 'Barchasi' : cat}
              </button>
            ))}
          </div>

          {/* 8 Certificate Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {displayedCertificates.map((cert, index) => (
              <CertificateCard
                key={cert.id}
                item={cert}
                onClick={() => onOpenCertificate(cert)}
                index={index}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ================= 5. "DUNYONING TOP-1000 UNIVERSITETLARI BILAN HAMKORLIK" (image_1a697f91.png) ================= */}
      <section id="hamkorlar" className="py-16 sm:py-20 px-4 sm:px-6 max-w-7xl mx-auto space-y-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-3">
            <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
              Dunyoning top-1000 universitetlari bilan hamkorlik
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base leading-relaxed">
              Smart Start xalqaro reytingda (QS World University Rankings) top-1000 talikka kiruvchi xorijiy universitetlar bilan hamkorlik qiladi. Bu bitiruvchilarimizga chet elda o'qish yo'lini ochadi.
            </p>
          </div>

          <div className="lg:col-span-5 space-y-2.5 bg-slate-50 dark:bg-slate-900/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300 font-semibold">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Hamkorlik mazmuni: qabulda to'g'ridan-to'g'ri tavsiya</span>
            </div>
            <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300 font-semibold">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Yozgi maktab yoki onlayn xalqaro kurslar</span>
            </div>
            <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300 font-semibold">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Xalqaro grant yoki chegirma imkoniyatlari</span>
            </div>
          </div>
        </div>

        {/* 6 Partner University Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { name: 'Oxford Int. College', country: 'Buyuk Britaniya', qs: 'QS #1', code: 'OX' },
            { name: 'TU Munich (TUM)', country: 'Germaniya', qs: 'QS #28', code: 'TUM' },
            { name: 'KAIST University', country: 'Janubiy Koreya', qs: 'QS #56', code: 'KAIST' },
            { name: 'Univ. of Bristol', country: 'Buyuk Britaniya', qs: 'QS #54', code: 'BRIS' },
            { name: 'Politecnico di Milano', country: 'Italiya', qs: 'QS #111', code: 'POLI' },
            { name: 'Univ. of Warsaw', country: 'Polsha', qs: 'QS #262', code: 'UW' }
          ].map((uni, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col items-center text-center space-y-2.5"
            >
              <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-xs font-mono font-bold text-[#13294B] dark:text-amber-400">
                {uni.code}
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900 dark:text-white leading-tight">
                  {uni.name}
                </h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {uni.country} · <span className="font-semibold text-emerald-600 dark:text-emerald-400">{uni.qs}</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ================= 6. "TA'LIM BOSQICHLARI" (image_1a697f91.png bottom) ================= */}
      <section id="talim" className="py-16 bg-slate-100/70 dark:bg-[#0B1A33]/40 border-y border-slate-200 dark:border-slate-800 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto space-y-8">
          <div>
            <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
              Ta'lim bosqichlari
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-sm mt-1">
              Har bir yosh davrining psixologik va intellektual xususiyatlariga moslashtirilgan o'quv dasturi.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Stage 1 */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs flex flex-col">
              <div className="h-44 bg-gradient-to-br from-blue-100 to-indigo-100 dark:from-slate-800 dark:to-slate-850 p-6 flex items-center justify-center text-center">
                <span className="font-display font-bold text-lg text-slate-700 dark:text-slate-300">
                  Boshlang'ich sinflar (1–4)
                </span>
              </div>
              <div className="p-6 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-mono font-bold text-[#CF9E2E] block">1–4-sinflar</span>
                  <h3 className="font-bold text-lg text-[#13294B] dark:text-white">
                    Poydevor va erta rivojlanish
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                    Savodxonlik, tez va to'g'ri o'qish, mental arifmetika, ingliz tiliga erta qiziqish va ijodiy fikrlash to'garaklari.
                  </p>
                </div>
              </div>
            </div>

            {/* Stage 2 */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs flex flex-col">
              <div className="h-44 bg-gradient-to-br from-emerald-100 to-teal-100 dark:from-slate-800 dark:to-slate-850 p-6 flex items-center justify-center text-center">
                <span className="font-display font-bold text-lg text-slate-700 dark:text-slate-300">
                  O'rta maktab (5–9)
                </span>
              </div>
              <div className="p-6 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-mono font-bold text-[#CF9E2E] block">5–9-sinflar</span>
                  <h3 className="font-bold text-lg text-[#13294B] dark:text-white">
                    Fundamental fanlar va CEFR
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                    Chuqurlashtirilgan matematika, fizika, ingliz tilidan milliy va xalqaro CEFR B2/C1 imtihonlariga tizimli tayyorgarlik.
                  </p>
                </div>
              </div>
            </div>

            {/* Stage 3 */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs flex flex-col">
              <div className="h-44 bg-gradient-to-br from-amber-100 to-orange-100 dark:from-slate-800 dark:to-slate-850 p-6 flex items-center justify-center text-center">
                <span className="font-display font-bold text-lg text-slate-700 dark:text-slate-300">
                  Yuqori maktab (10–11)
                </span>
              </div>
              <div className="p-6 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-mono font-bold text-[#CF9E2E] block">10–11-sinflar</span>
                  <h3 className="font-bold text-lg text-[#13294B] dark:text-white">
                    IELTS, SAT va OTMga qabul
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                    IELTS 7.5+, SAT 1400+, xorijiy va mahalliy nufuzli oliygohlarga 100% grant yutish maqsadida shaxsiy portfolio yaratish.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= 7. "BIZNING USTOZLAR" (image_9840922e.png top) ================= */}
      <section id="oqituvchilar" className="py-16 sm:py-20 px-4 sm:px-6 max-w-7xl mx-auto space-y-8">
        <div>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
            Bizning tajribali ustozlarimiz
          </h2>
          <p className="text-slate-600 dark:text-slate-400 text-sm mt-1">
            Xalqaro sertifikatlarga ega, ko'p yillik tajribali metodist va o'qituvchilar jamoasi.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { name: 'John Miller', role: 'Ingliz tili (IELTS)', exp: '10 yil tajriba', score: 'IELTS 8.5' },
            { name: 'Dr. Rustam Karimov', role: 'Matematika & SAT', exp: '14 yil tajriba', score: 'SAT 1520' },
            { name: 'Dilnoza Rahimova', role: "Boshlang'ich sinf", exp: '12 yil tajriba', score: 'Metodist' },
            { name: 'Alisher Saidov', role: 'Ona tili va adabiyot', exp: '15 yil tajriba', score: 'Oliy toifa' }
          ].map((teacher, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs hover:shadow-md transition-shadow space-y-3"
            >
              <div className="h-32 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-400">
                <Users className="w-8 h-8 text-[#13294B] dark:text-amber-400" />
              </div>
              <div>
                <h4 className="font-bold text-base text-slate-900 dark:text-white">
                  {teacher.name}
                </h4>
                <p className="text-xs text-[#CF9E2E] font-semibold mt-0.5">
                  {teacher.role} · {teacher.score}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {teacher.exp}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ================= 8. "ERTALABDAN KECHGACHA — BIR KUN SMART START'DA" (image_9840922e.png bottom) ================= */}
      <section id="kun" className="bg-[#13294B] text-white py-16 px-4 sm:px-6 lg:px-8 border-y border-slate-800">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column */}
          <div className="lg:col-span-5 space-y-5">
            <span className="inline-block px-3 py-1 rounded-full bg-white/10 text-amber-300 text-xs font-bold border border-white/15">
              Bir kun Smart Start'da
            </span>

            <h2 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight leading-tight">
              Ertalabdan kechgacha — farzandingiz ishonchli qo'llarda
            </h2>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              To'liq kun rejimi: darslar, ovqat, dam olish, uy vazifasi va to'garaklar bitta binoda. Ishdan keyin farzandingizni vazifasi to'liq bajarilgan holda olib ketasiz.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={onOpenAdmissionModal}
                className="px-6 py-3 rounded-xl bg-[#CF9E2E] hover:bg-[#b88c27] text-[#13294B] font-extrabold text-sm transition-all shadow-md active:scale-95 cursor-pointer"
              >
                Ekskursiyaga yozilish
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('qabul')}
                className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-sm transition-all cursor-pointer"
              >
                Narxlarni bilish
              </button>
            </div>
          </div>

          {/* Right Column: Timeline Schedule */}
          <div className="lg:col-span-7 space-y-4">
            {[
              { time: '[08:00]', title: 'Kutib olish va nonushta', desc: "O'qituvchilar bolalarni eshik oldida iliq kutib oladi va energiya beruvchi nonushta." },
              { time: '[08:30]', title: 'Asosiy darslar', desc: 'Kichik sinflarda, 45 daqiqalik qiziqarli va interaktiv taʼlim darslari.' },
              { time: '[12:30]', title: 'Tushlik va dam olish', desc: "Issiq 3 mahal muvozanatli ovqat va ochiq havoda xavfsiz o'yin/sayr." },
              { time: '[14:00]', title: 'Ingliz tili', desc: "Qo'shimcha soatlar, so'zlashuvga (Speaking club) asosiy amaliy urg'u." },
              { time: '[15:30]', title: 'Uy vazifasi', desc: "O'qituvchi nazoratida, maktabning o'zida to'liq va mustaqil bajariladi." },
              { time: '[16:30]', title: "To'garaklar", desc: 'Robototexnika, shaxmat, sport, tasviriy sanʼat va mental arifmetika.' }
            ].map((step, idx) => (
              <div
                key={idx}
                className="flex items-start gap-4 pb-3.5 border-b border-slate-700/60 last:border-b-0"
              >
                <span className="font-mono font-bold text-[#CF9E2E] text-xs sm:text-sm shrink-0 pt-0.5">
                  {step.time}
                </span>
                <div className="space-y-0.5">
                  <h4 className="font-bold text-sm sm:text-base text-white">
                    {step.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-300">
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= 9. "OTA-ONALAR NIMA DEYDI" (image_1beebe7e.png top) ================= */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 max-w-7xl mx-auto space-y-10">
        <div>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
            Ota-onalar nima deydi
          </h2>
          <p className="text-slate-600 dark:text-slate-400 text-sm mt-1">
            Maktabimizda tahsil olayotgan o'quvchilarning ota-onalari samimiy fikrlari.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              quote: "Farzandim 2 yildan beri Smart Start'da o'qiydi. Ingliz tili darajasi va mustaqil fikrlashi kutilganimdan ancha yuqori bo'ldi. Eng muhimi, har kuni maktabga xursand boradi.",
              author: 'Gulnora Qosimova',
              sub: "8-sinf o'quvchisining onasi"
            },
            {
              quote: "Uy vazifasini maktabning o'zida o'qituvchi nazoratida bajarishi bizdek ishlaydigan ota-onalar uchun katta yengillik. Kechqurun uyda dars qildirish stressi yo'q.",
              author: 'Botir Zokirov',
              sub: "5-sinf o'quvchisining otasi"
            },
            {
              quote: "O'tgan yili farzandim IELTS topshirib 7.5 oldi va tuman olimpiadasida 1-o'rinni egalladi. Ustozlarning mehnati va individual yondashuvidan juda minnatdormiz!",
              author: 'Nargiza Karimova',
              sub: "11-sinf o'quvchisining onasi"
            }
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
            >
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 italic leading-relaxed">
                "{item.quote}"
              </p>
              <div className="border-t border-slate-100 dark:border-slate-800 pt-3">
                <div className="font-bold text-sm text-[#13294B] dark:text-white">
                  {item.author}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {item.sub}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ================= 10. "MAKTAB HAYOTI" (image_1beebe7e.png & image_d2122009.png top) ================= */}
      <section id="yangiliklar" className="py-16 bg-slate-100/70 dark:bg-[#0B1A33]/40 border-y border-slate-200 dark:border-slate-800 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
              Maktab hayoti
            </h2>
            <button
              type="button"
              onClick={onOpenAdmissionModal}
              className="text-xs sm:text-sm font-bold text-[#13294B] dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Barcha yangiliklar →</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                tag: 'Tadbir',
                date: '15-Mart, 2026',
                title: 'Ochiq eshiklar kuni — maktabimiz bilan tanishing',
                desc: "Ota-onalar uchun maktab bo'ylab ekskursiya, ustozlar bilan ochiq muloqot va namunaviy darslar."
              },
              {
                tag: 'Yutuq',
                date: '28-Fevral, 2026',
                title: "O'quvchimiz tuman olimpiadasida g'olib bo'ldi",
                desc: "Matematika va ingliz tili yo'nalishida 5 nafar o'quvchimiz faxrli 1 va 2-o'rinlarni egalladi."
              },
              {
                tag: "E'lon",
                date: '10-Yanvar, 2026',
                title: "Qishki ta'til jadvali va qo'shimcha to'garaklar",
                desc: 'Robototexnika va shaxmat boʻyicha qishki oromgoh dasturi tasdiqlandi.'
              }
            ].map((news, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs hover:shadow-md transition-shadow flex flex-col"
              >
                <div className="h-40 bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 text-xs font-semibold">
                  [Tadbir fotosurati]
                </div>
                <div className="p-5 space-y-2 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                      <span className="font-bold text-[#CF9E2E]">{news.tag}</span>
                      <span>{news.date}</span>
                    </div>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white leading-snug">
                      {news.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                      {news.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= 11. "QABULGA ARIZA QOLDIRING" (image_d2122009.png bottom) ================= */}
      <section id="qabul" className="py-16 sm:py-20 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Heading and 4 steps */}
          <div className="lg:col-span-5 space-y-6">
            <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
              Qabulga ariza qoldiring
            </h2>

            <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base leading-relaxed">
              Joylar soni cheklangan. Arizangizni qoldiring — menejerimiz 1 ish kuni ichida qo'ng'iroq qiladi va maktabga tanishuvga taklif qiladi.
            </p>

            <div className="space-y-4 pt-2">
              <div className="flex items-start gap-3">
                <span className="font-bold text-[#CF9E2E] text-base shrink-0">1.</span>
                <p className="text-sm text-slate-700 dark:text-slate-300">
                  <strong className="text-slate-900 dark:text-white">Ariza</strong> — saytda yoki telefon orqali yuboriladi
                </p>
              </div>

              <div className="flex items-start gap-3">
                <span className="font-bold text-[#CF9E2E] text-base shrink-0">2.</span>
                <p className="text-sm text-slate-700 dark:text-slate-300">
                  <strong className="text-slate-900 dark:text-white">Tanishuv</strong> — maktab va o'qituvchilar bilan bevosita ko'rishish
                </p>
              </div>

              <div className="flex items-start gap-3">
                <span className="font-bold text-[#CF9E2E] text-base shrink-0">3.</span>
                <p className="text-sm text-slate-700 dark:text-slate-300">
                  <strong className="text-slate-900 dark:text-white">Diagnostik suhbat</strong> — imtihon emas, bolaning qobiliyatini aniqlash
                </p>
              </div>

              <div className="flex items-start gap-3">
                <span className="font-bold text-[#CF9E2E] text-base shrink-0">4.</span>
                <p className="text-sm text-slate-700 dark:text-slate-300">
                  <strong className="text-slate-900 dark:text-white">Shartnoma</strong> — va muvaffaqiyatli o'qish boshlanadi
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Inline Application Card Form */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xl">
            {submitSuccess ? (
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 flex items-center justify-center text-emerald-600 mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-display font-bold text-2xl text-slate-900 dark:text-white">
                  Arizangiz qabul qilindi!
                </h3>
                <p className="text-xs font-mono bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded inline-block text-slate-700 dark:text-slate-300">
                  Ariza raqami: {appNumber}
                </p>
                <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto">
                  Rahmat, {parentName}! Tez orada qabul komissiyasi siz bilan bog'lanadi. Xabarnoma maktab ma'muriyati Telegram botiga ham yetkazildi.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSubmitSuccess(false);
                    setParentName('');
                    setStudentName('');
                    setNotes('');
                  }}
                  className="px-6 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                >
                  Yana boshqa ariza yuborish
                </button>
              </div>
            ) : (
              <form onSubmit={handleInlineSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 block">
                      Ota-ona ismi *
                    </label>
                    <input
                      type="text"
                      required
                      value={parentName}
                      onChange={(e) => setParentName(e.target.value)}
                      placeholder="Masalan, Alisher Qosimov"
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#CF9E2E]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 block">
                      Telefon raqam *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+998 90 123 45 67"
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#CF9E2E]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 block">
                      Farzandning ismi *
                    </label>
                    <input
                      type="text"
                      required
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="O'quvchi ismi"
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#CF9E2E]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 block">
                      Qaysi sinfga? *
                    </label>
                    <select
                      value={grade}
                      onChange={(e) => setGrade(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#CF9E2E]"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((g) => (
                        <option key={g} value={`${g}-sinf`}>{g}-sinf</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 block">
                    Izoh (ixtiyoriy)
                  </label>
                  <textarea
                    rows={3}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Masalan, ingliz tili darajasi, olimpiada qiziqishlari..."
                    className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#CF9E2E]"
                  />
                </div>

                {errorMessage && (
                  <p className="text-xs text-red-500 font-semibold">{errorMessage}</p>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 rounded-xl bg-[#CF9E2E] hover:bg-[#b88c27] active:scale-98 text-[#13294B] font-extrabold text-base transition-all shadow-md cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? "Yuborilmoqda..." : "Ariza yuborish"}</span>
                </button>

                <p className="text-[11px] text-center text-slate-400">
                  Yuborish orqali shaxsiy ma'lumotlarni qayta ishlashga rozilik bildirasiz.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* ================= 12. "BIZ BILAN BOG'LANING" (image_ed813eba.png top) ================= */}
      <section id="aloqa" className="py-16 sm:py-20 bg-slate-100/70 dark:bg-[#0B1A33]/40 border-y border-slate-200 dark:border-slate-800 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5 space-y-6">
            <h2 className="font-display font-black text-3xl sm:text-4xl text-[#13294B] dark:text-white tracking-tight">
              Biz bilan bog'laning
            </h2>

            <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base leading-relaxed">
              Savolingiz bormi? Qo'ng'iroq qiling, Telegram'da yozing yoki maktabga keling.
            </p>

            <div className="space-y-4 text-xs sm:text-sm">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#CF9E2E] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Manzil:</span>
                  <span className="text-slate-600 dark:text-slate-400">
                    Toshkent shahri, Chilonzor tumani, Bunyodkor shox ko'chasi
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-[#CF9E2E] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Telefon:</span>
                  <span className="text-slate-600 dark:text-slate-400 font-mono">
                    +998 71 200 00 22 / +998 90 994 74 07
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MessageCircle className="w-4 h-4 text-[#CF9E2E] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Telegram:</span>
                  <a
                    href="https://t.me/stmartstartt_bot"
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-600 dark:text-amber-400 hover:underline font-mono"
                  >
                    @stmartstartt_bot
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-[#CF9E2E] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Ish vaqti:</span>
                  <span className="text-slate-600 dark:text-slate-400">
                    Du–Ju 08:00–18:00, Sh 09:00–14:00
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Map Card */}
          <div className="lg:col-span-7">
            <div className="rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xl overflow-hidden aspect-[16/10] flex flex-col justify-between">
              <div className="w-full h-full rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 relative overflow-hidden flex flex-col items-center justify-center p-6 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-950/60 border border-red-300 dark:border-red-700 flex items-center justify-center text-red-600 shadow-md">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white text-base">
                    Smart Start Xususiy Maktabi
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Toshkent, Chilonzor tumani (Bunyodkor shox ko'chasi)
                  </p>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                  <a
                    href="https://yandex.com/maps/?text=Smart+Start+xususiy+maktabi+Toshkent"
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <span>Yandex Xaritada ochish</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href="https://maps.google.com/?q=Smart+Start+School+Tashkent"
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <span>Google Maps</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= 13. FOOTER (image_ed813eba.png bottom) ================= */}
      <footer className="bg-[#0B1A33] dark:bg-slate-950 text-white py-12 px-4 sm:px-6 border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <img
              src="/smart-start-logo.png"
              alt="Smart Start Logo"
              className="w-12 h-12 object-contain"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/b9beb49f5a7d0c49502c2b2852bb209a.png';
              }}
            />
            <div>
              <h3 className="font-display font-bold text-lg text-white">Smart Start</h3>
              <p className="text-xs text-slate-400">
                xususiy maktabi · 2022-yildan beri · Davlat litsenziyasi № 048219
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6 text-xs text-slate-300 font-semibold">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-amber-400 transition-colors"
            >
              Instagram
            </a>
            <a
              href="https://t.me/stmartstartt_bot"
              target="_blank"
              rel="noreferrer"
              className="hover:text-amber-400 transition-colors"
            >
              Telegram
            </a>
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-amber-400 transition-colors"
            >
              YouTube
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};
